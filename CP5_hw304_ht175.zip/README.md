Group member：
name：huidan Tan
netid： ht175
name：hongshu Wang
netid： hw304

Design：
ALU part:
ctrl_readRegA:  Because in bex instruction, we need to compare rstatus with 0. In order to reuse previous ALU, we use a mux for ctrl_readRegA. When there is a bex instruction, we let ctrl_readRegA be 11111 otherwise we let it be instruction[21:17].

ctrl_readRegB:  in bne,blt instruction, we need to compare rs with rd. In order to reuse previous ALU, we use a mux for ctrl_readRegB. Meanwhile for jr instruction, we need to let pc equals to rd. Therefore, for jr instruction, to read rd,  we also need ctrl_readRegB be instruction[26:22]. All in all, when there is a blt instruction or bne instruction or jr instruction or sw instruction(previous design) , we let ctrl_readRegB be instruction[26:22] otherwise we let it be instruction instruction[16:12](rt).


ctrl_writeEnable: for setx and jal, we need write something to register file. Therefore, we use a or gate to combine setx, jal and previous writeEnable instructions together.


PC part:

PC plus one: we use a alu to achieve pc+1
PC Plus one and N: we let the result of pc+1 be the input to a new alu, and let inputB be the immediate N.
PC+1/PC+1+N/PC=rd/PC=T: we use several muxes to determine the value of PC.
